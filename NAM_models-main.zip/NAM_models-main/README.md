This is a collection of model files for the Neural Amp Modeler as developed by Steve Atkinson - https://github.com/sdatkinson/neural-amp-modeler

These files have been made by the Neural Amp Modeler community on the facebook group at https://www.facebook.com/groups/5669559883092788

These files are licenced under the GNU GPL v3, please see the file COPYING for more details.


To those new to github .. there's an easy way to download all the captures in one go.  Click the green "Code" button at the top right, then "Download ZIP" at the bottom of that.  That will package all the captures up into a ZIP archive and download it for you.
